# Workman Nigeria

A simple, mobile-friendly home-services directory and price-estimate calculator built with plain HTML, CSS and JavaScript. It can be hosted free with GitHub Pages.

## Run it on your phone or computer
1. Download and unzip `workman-nigeria.zip`.
2. Open the `index.html` file in Chrome, Firefox or another browser.

## Publish it with GitHub Pages
1. Sign in at https://github.com/ and create a new **public** repository, e.g. `workman-nigeria`.
2. Upload `index.html` and `README.md` to the repository's main/root folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch **main** and folder **/(root)**, then click **Save**.
6. Wait a minute or two. GitHub will show your website address, usually:
   `https://YOUR-USERNAME.github.io/workman-nigeria/`

## Important: customize before publishing
Open `index.html` and find:
- `const WHATSAPP_NUMBER = "2348012345678";`
  Replace this sample with your own WhatsApp number, digits only, including Nigeria's country code `234`.
- The `services` array contains the example service list and price ranges. Update every `min` and `max` value to prices you have checked with artisans in your target city.
- Update the Workman name and text if you want your own brand details.

## What is included
- Plumbing repairs and installation
- Tiling, DSTV, Wi-Fi, roofing
- Electrical work, painting, POP ceiling, carpentry and AC installation
- Search and category filters
- Quantity-based estimate calculator
- WhatsApp quotation request link

## Important limitations
This is a front-end starter app. It does not yet have user accounts, online payments, an artisan database, booking management, admin dashboard or a server/database. The displayed prices are illustrative planning ranges, not verified Nigerian market prices. Confirm the final price with the artisan after inspecting the job.
